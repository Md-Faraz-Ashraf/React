import { combineReducers} from 'redux'
import red1 from './red1'
import red2 from './red2'

export default combineReducers({
    Model1:red1,
    Comp2Model:red2
})