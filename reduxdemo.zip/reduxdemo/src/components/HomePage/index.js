import React, {useState, useEffect} from 'react'
import Comp1 from './comp1'
import Comp2 from './comp2'
import Comp3 from './comp3'
import Comp4 from './comp4'
import {connect} from 'react-redux'
import axios from 'axios'

// Api called in CDM.
// action dispatched to redux for response.
// props changed as new value comes from redux.
// CDU is called and has access to new props.


export default function UsersComponent(){
    const [userList, setUserList] = useState([])
    useEffect(async ()=>{
        const usersResponse = await axios.get('https://reqres.in/api/users?page=1&per_page=12')
        setUserList(usersResponse.data.data)
    },[])

    function displayUsers(){
        const jsxLists = []
        userList.forEach((thisUser)=>{
            jsxLists.push(
            <li>
                {`${thisUser.first_name} ${thisUser.first_name}` }
            </li>)
        })
        return jsxLists

    }
    return(
        <React.Fragment>
            <ul>
            {displayUsers()}
            </ul>
           
        </React.Fragment>
    )
}
