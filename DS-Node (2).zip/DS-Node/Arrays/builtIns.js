//a=[1,2,3,4,5]



// b=a.map(item=>
//     {console.log(item)
//     return item})

// for item in range (list):
// for i in ramge (0,9)

//For each. Executes the given function for each element
// a.forEach(()=>{});
// Can mutate calling array using index passed.
// a.map((item,index)=>{
//     a[index]=item*2
// })
// console.log(a)

// Returning new array. (creating new array by pushing into it)
// new_array=[]
//     a.map(item=>{
//         new_array.push(item*2)
//     })
// console.log(new_array)

// Returning new Array. (creating new array by creating through index referencing)
// new_array2=[]
// a.map((item,index) => {
//     new_array2[index]=item*2
// });
// console.log(new_array2)

//Array methods

//-------------------------------------------------indexOf/lastIndexof---------------------------------------
// b=[1,2,3,'s','d','f']
// console.log(b.indexOf('nonExixtent'))
// console.log(b.indexOf(3))

// function myIndexOf(a,key){
// Map will always create an array and you can return it.
//    return a.map((item,index)=>{
//         if (item==key){
//             return index
//         }
//    })
// }

// console.log(myIndexOf([12,34,56],34))
// Return an array [undefined,1,undefined]

// function myIndexOf(a,key){
//     for(var i=0;i<a.length;i++){
//         if (a[i]===key){
//             return i
//         }
//     }
//     return -1
// }
// console.log(myIndexOf([1,2,'fr'],'2'))

//---------------------------------------JOIN-------------------------
// Always retrun string.
// a=['f','a','r','a','z']
// b=a.join('')
// c=a.join('-')
// console.log(a)
// console.log(b)
// console.log(c)

// d=[1,2,3,4]
// e=d.join('')
// console.log(typeof(e))

//----------------------------------------- Splice----------------------
// a.splice(startIndex, No of elements)
// a = [1, 2, 3, 4, 5, 6, 7, 8];
// b = a.splice(3, 0);
// console.log(b);

//------------------------------------------Slice------------------------
    // a=[1,2,3,4,5,6,7,8,9]
    // b=a.slice(6)
    // console.log(b)

// ----------------------------------------Reverse --------------------------
// In place reverse. The original array is changed.
// a=[1,2,3,4,5,6,7,8,9]
// a.reverse()
// console.log(a)


//-------------------------------------------Sort----------------------------
//Sorting in Increasing order
// Numbers--Capital Alphabets-- Small Alphabets -- undefined
// a=[4,1,0,10,'x',-5,9,23,12,45,'w',90]
// b=['b','B','z',undefined,'a','d','c','Z',-10,0,99,0.5,undefined, NaN, null]
// a.sort()
// b.sort()
// console.log(a)
// console.log(b)

//-------------------------------------------includes---------------------------
// Strictly checks for inclusion
//includes(key, startSearchIndex)
// a=['b','B','z',undefined,{},'a','d','c','Z',-10,0,99,0.5,undefined, NaN, null]
// console.log(a.includes('a'))
// console.log(a.includes('A'))
// console.log(a.includes('99'))
// console.log(a.includes(99))
// console.log(a.includes({}))

//------------------------------------------Creating and Manipulating  Dictionary In JS--------------------------------

//  a=[1,1,4,4,6,3,7,9,8,9,3,3,2,1,2]
//  dict={}

// Method 1 -- By checking if value of dict[key] is undefined.
// for(i=0;i<a.length;i++){
//     key=a[i]
//    if(dict[key]==undefined){
//        //Creating Key and assigning value.
//        dict[key]=1
//    }else{
//        dict[key]=dict[key]+1
//    }
// }

// Method 2 -  using 'key in' -- PREFFERED !
// for(i=0;i<a.length;i++){
//     key = a[i]
//     if(!(key in dict)){
//         // If key not in dict, then we create it and assign a value 1.
//         dict[key]=1
//     }
//     else{
//         dict[key]=dict[key]+1
//     }
// }

//Method 3 -- using 'hasOwnProperty'
// when you just declare a variable and not assign a value to it- it is undefined.
// when you try and perform math on undefined you get NaN
// for(i=0;i<a.length;i++){
//     key=a[i]
//     if(!dict.hasOwnProperty(key)){
//         // If dict does not have the property, the you are creating a property and assiging 1 to it.
//         dict[key]=1
//     }
//     else{
//         dict[key]=dict[key]+1
//     }
// }

//Method 4
// Using similar technique as in Python-- for item in a:
// Most like Python !
// for(item of a){
        //for of is used to iterate over items in iterables.
//     if(!(item in dict)){
        //for in is used to iterate over keys in objects and index in case of array and string.
//         dict[item]=1
//     }
//     else{
//         dict[item]=dict[item]+1
//     }
// }
// console.log(dict)

//--------------------------------------------------------- Stack And Queues Operations!--------------------------------------

// a=[1,2,3,4,5]
// console.log(a.push(12,34)) // Appends elements at the end and returns length of new array and not the array itself!.---->a.append()
// console.log(a.pop()) // Removes the last element from array, and returns it. It takes no argument..... a.remove()
// console.log([].pop()) // Pop on empty array--> undefined.
// console.log(a.shift()) // Pop elements from start of an array.
// console.log(a.unshift(-1,0)) // Inserts elements at the beginning, and return the new length.
//Pop and Shift works the same way.
//Push and unshift works the same way.

//-------------------------------------------Concat/valueOf----------------------------------
// a=[1,2,3,4,'sad']
// b=[5,6,7,8,9,[10,11]]
// console.log(a.concat(b,[22,33,44]))
// console.log(a.valueOf())

//--------------------------------------------entries---------------------------------------Not much used!
// a=['a','b','c','c','d']
// iterator=a.entries()
// for(entry of iterator){
//     console.log(entry)
// }

//-------------------------------------------Truthy and Falsy---------------------------------------------
// Falsy Values -- 0, undefined, null, NaN, false, ''


//---------------------------------------------Functional Programming------------------------------------
//Functional Programming is a programming paradigm where you mostly construct and structure your code using functions. 
//Well the real power of this paradigm comes from passing functions to functions (and returning functions from functions).
//Functional programming is about writing pure functions, about removing hidden inputs and outputs as far as we can,
// so that as much of our code as possible just describes a relationship between inputs and outputs.
// Functional programming thus has no side causes and side effects.
// It makes testing in isolation posssible.
//A functional programming language is one that supports and encourages programming without side-effects.
//So, a pure functional language is simply one in which a function cannot observe things besides its inputs.03
//Key features: 
        //Pure functions
        //Function composition
        //Avoid shared state
        //Avoid mutating state
        //Avoid side effects
// It is a common pattern in JS to make a copy of an object and then make changes in it and return it as new value for thet function.
// Function Composition-- Write functions whose outputs will naturally work as inputs to many other functions. 
//Keep function signatures as simple as possible.
//You can’t call it a Functional Programming if there’s a shared state, objects mutate, or there’s some leakage outside of its function scope in any way. It should be limited to its function scope.
// Why react says never to mutate objects?

// str='abcd'
// console.log(str)
// str[0]='f' // Since strings are not arrays in JS. This does not work. JS silently ignores mutation attempt.
// console.log(str)
// str="efgh" // This assign a diffrenet string to str pointer.  Does not modify abcd to efgh.
// console.log(str)


// Primitives are immubtable but reassignable. While with objects reassignment to object properties itself mean mutation.
// let x = 5
// badInc = () => { x = x + 1; return x }
// badDbl = () => { x = x * 2; return x }
// console.log(badInc(x))
// console.log(badDbl(x))
// console.log(badInc(x) + badDbl(x)) 



//const declaration prevents reassignment, not mutation.
// With object mutaion means changing the values of the properties of an object,
// const obj = {}
// const arr = []
// const fnc = () => {}

// //obj={'a':'1'} // Assignment to const variable error
// obj.mutated = true // But mutation is still possible.
// arr.mutated = true
// fnc.mutated = true
// console.log(obj.mutated, arr.mutated, fnc.mutated) // true x 3


// --------------------------Freezing objects to Avoid mutation---------------------------------------
// We can use Object.freeze to avoid mutation on first level properties of the object.
// const obj = { example: 9000 }
// obj.example=obj.example+1
// Object.freeze(obj) // Freezing the object which now is  - { example:9001}
// obj.example++ // silently ignored in non-strict mode (error in strict mode)
// console.log(obj.example) // 9001, not 9002
//Beware, however – freeze only prevents re-assigning top-level properties, and does not prevent mutating objects referenced in those properties. 
//For that, you need a non-native "deep freeze" algorithm which recursively freezes objects.

// So how do we avoid Mutaion in objects and arrays?
//--- We make use of Spread Syntax Or Object.assign() function.


// Creating New versions of an array without mutaion---------------------------
//Example.1 
    //Adding new values 
        // a=[1,2,3,4,5]
        // newA =[...a,6,7,8]
        // console.log(a)
        // console.log(newA)

//Example.2
    // Removing Value. (using slice)
        // const arr = ['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet']
        // const withoutYellow = [...arr.slice(0, 2), ...arr.slice(3)]
        // console.log(arr, withoutYellow)

//Example.3
    // Updating Values
        // const arr = ['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet']
        // const YellowToPink='pink'
        // const newArr=[...arr.slice(0,2),YellowToPink,...arr.slice(3)]
        // console.log(newArr)

//---------------------Incorerct way of updating state-----------------------
// updateState(event) {
//     const {name, value} = event.target;
//     let user = this.state.user; // this is a reference, not a copy. It still points to same global state.
//                                 // Thus any change to this will affect global state.
//     user[name] = value; // so this mutates state !-- Which is not recommended by React.
//     return this.setState({user});
//    }
// Why do react tell us not to mutate state?
        //Never mutate this.state directly, as calling setState() afterwards may replace the mutation you made. 
        //Treat this.state as if it were immutable.

//Ways to treat state as Immutable:
    //1. Object.assign()
    //2. Object Spread 
        // No matter what approach you use in react. ultimately the newly creted object has to be passed as argument to setState() function.
        // Any change detected through setState is used to update the component.

        // Gochcha -- Since Object.assign and Object Spread makes a shallow copy of object, the nested inner objects within are
        // not actually copied rather just their refernces are copied. Thus now if you make any change to inner object properties,
        //It will directly mutate the global state.
        // Thus by the time setState() function is called with newly consrtructed state object, there wont be any change detected.
        // And thus the component won't update !.
        // Thus in those cases we need to create deep copy of the state object.

//Modifying Props would be two-way-binding. If we modify props in child there will be inconsistency in the data at diferent levels.
// This is becuase React supports one way binding. Data cannot flow up the tree. 




// Function that returns 1, 2, 3 in subsequent calls.
// x=0
// function random(){
//     x++
//     console.log(x)
// }
// random()
// random()
// random()
// console.log('x',x)

// Same using Closure.
// function printFunction(){
//     n=0;
//     return function printNumber(){
//         n=n+1
//         console.log(n)
//     }
// }
// var myFunc = printFunction()
// myFunc()
// myFunc()
// myFunc()

//--------------------------------fill--------------------------------------------
// a=[1,2,3,4,5]
// a.fill(9,0,2)
// //value, statring index, no of fillings
// // Mutates Array
// console.log(a)

//----------------------------------forEach()----------------------------------
// a=[1,2,3,4,5]
// a.forEach(element => {
//     console.log(element**2)
// });
// console.log(a)

// // If callback of map does not return anything it will return undefined.
// // We must return something for each element.
// b=a.map(element=>{
//      element**2
// })
// console.log(b)

// b=a.map(element=>{
//     return element**2
// })
// console.log(b)

// JS is dynamicaly typed. We never have to specify the data type of the variable. It ia only determined at run time on its own.
// Statically typed languages verify datatypes at compile time itself.
// Earlier JS was only interpreted, but recently after V8 engine it is JIT compiled.
// Interpreted langaguges -- Slower with execution, but faster to debug.
// Compiled langauges -- Faster execution, but harder to debug. 
// So, Now we have mixture of both called - JIT. It coverts neither complete HLL code to MLL, nor just one instruction at a time.
// But rather sets of insturction. Compile alil then run. Repeat!

//v8 Points:
    //1. Compile sets of JS instructions.
    //2. JS Code -> Parser --> AST --> Ignition --> Byte code.
    //3. It is javascript run time. -->parsing, compilng and running.
    //4. Implements JS as per Ecma standards,
    //5. Does Garbage Collection for JS.
    //6. Does not implement DOM or Console.
    //7. No File system access. Node uses Lib UV for it.

// How languages work:
    // 1. We code to instruct the microprocessors.
    // 2. But microprocessors understands only machine language.
    // 3. But it is not feasable so us humans to write machine level language.
    // 4. So we use high level language like c, JS, python, JS etc.
    // 5. Thus we need a compiler or interpretor for HLL->MLL.
    // 6. How Compiler Works:
            // HLL --> MLL (All code at a time) --> Executable code-->Processed by processor.
            // Thus compiles Langauages have an overhead of compilation, but once compiled, the excutable is much faster.
    // 7. How interpretor Works:
            // 1 line HLL --> 1 Line MLL --> 1 Line processed.
            // Thus Run time reaches faster.



//------------------------Object Methods-------------------------

// Obejct.keys(obj) -- > [key1,key2,key3...]
// // Length of an object = no of keys it has = Object.keys(obj).length
// a={}
// console.log(Object.keys(a).length)
// //Object.values(obj)
// //Object.entries(obj)
// a={'a':1,'b':2,c:{'de':90,'f':{'s':0}}}
// console.log(Object.entries(a)[2])
// //Object.assign() --- To merge two objects.
// newObj={b:2,a:'a'}
// Object.assign(newObj,{'a':2,c:3})
// console.log(newObj)
// //Object,Freeze()
// //Object.seal()

//---------------------------- Prototype Chaining------------------------------
// Any function expression in JS is a constructor.
// Now constructor can be used to create new objects using new keyword.
// There is a propertry called prototype for every Object in JS.
// We can defined variables and methods in prototypes of a constructor function.
// Whenever we create an object from that constructor, the newObj inherits the variables and methods mentioned in the prototype of it's constructor.
// newObj will have it's own variables and methods for all the normal variables and methods there in the constructor.
// This newObj has access to all the variables and methods in the prototype of it's parent constructor, which in turn has access to prototype of it's
// parent constructor, untill the the top most parent ie, Object constuctor is reached.
// If a JS object is calling a method, JS checks is this object has it as it's own property. If not it checks if it is present in the prototype of it's parent constructor.
// Example: 
// function X (name){
//     this.name=name, 
//     this.getName=function(){
//         return this.name
// }
// } // This is constructor fumction

// const x1=new X('Faraz')
//  console.log(x1.getName())
// // console.dir(x.__proto__) //Function
// // console.dir(x.__proto__.__proto__) //Object
// // console.dir(x.__proto__.__proto__.__proto__) //null
// console.log(X.prototype)

// There is something called proptotype property of the constructor.Where we define the methods and properties for inhertitance
// And there is something called prototype property of an object. This prototype property has to be made equal to prototype of the constructor fot inheritance to happen.

//Whenever you try to get a property on an object it will check the object for that property name. If it does not exist it will look in the prototype.
//every object created using the constructor function will have its own copy of properties and methods.
//Storing separate instances of function for each object results into wastage of memory. 
//When a function is created in JavaScript, the JavaScript engine adds a prototype property to the function. This prototype property is an object (called as prototype object) which has a constructor property by default.
//The constructor property points back to the function on which prototype object is a property. 


// Creating Constructor function-->Any function declaration in JS--> Engine adds a prototype property to it. --> Prototype property holds an object--> This prototype object holds the function itself.
// Creating an Object using constructor function--> Engine adds __proto__ property to newly created object. It points to Prototype object of the constructor function.
// Constructor.prototype and object.__proto__ points to same object which is protptype object !!
// Constructor.prototype === object.__proto__ //true
// All the objects that we create from a constructor will have a __proto__ property and all will point to the same object, which is prototype Object of the constructor.
// Prototype object of the constructor function is shared among all the objects created using the constructor function.
// When we try to call a method or property of on object, JS Engine checks if thet object has that property or not.
// If not found, it checks for the same in the dunder proto (__proto__) of the object.
// What does dunder proto contain?.. Nothing but the Prototype object of it's constructor.
// Thus it now actually checks for the called property or method on prototype property on the constructor.
// What does prototype proerty of constructor contain?... Some properties, methods and it's dunder proto. 
// Thus if the desired property is not found in the protptype object of the constructor as well, JS engines goes to Prototype Object of Consturctor of the Constructor function through it's dunder proto.
// This process continues untill dunder prorto is found to be null.
// Once dunder proto is found to be null, we say that property or method is undefined.
// Each object created from the constructor gets its own copy of methods.
// Any modification to the property of the prototype object by a new object makes it available to all the objects being constructed through that constructor.
//To solve both problems, we can define all the object-specific properties inside the constructor and all shared properties and methods inside the prototype.

//----------------------------------------------------Event Loop-------------------------------------------------
// JS is single threaded means?
        // JS IS BY DEFAULT SINGLE THREADED AND BLOCKING, BUT WE REFER TO IT AS ASYNCHRONOUS BECAUSE WE CAN MAKE IT BEHAVE SUCH
                    // WITH THE HELP OF WEB APIS, CALL STACK, EVENT LOOP AND EVENT QUEUE !.. THIS IS JUST AN ILLUSION.
                    // CODE THAT MAKE USE OF WEB APIS CAN BE HANDLED USING EVENT LOOP. BUT WHAT ABOUT A VERY LONG WHILE LOOP??
                    // CODE IS BLOCKING IN JS MEANS THAT ITS EXECUTION HAPPENS SOULY IN CALL STACK WITHOUT USING WEB API.
                    // SO ANY SUCCEEDING CODE IS BLOCKED UNTILL IT FINISHES.

        // Only one main thread on which JS code is executed.
        // Only one line of code is executed at a time.
        // By default JS is blocking due to its single threaded nature.
        // To make Non blocking we use callbacks, Promises or async await!
        // But as JS is single threaded and    

//Call Stack: (The second sort of memory availble in JS is heap!)
        //JavaScript has a single call stack in which it keeps track of what function we’re currently executing and what function is to be executed after that.
// Web Api's:
        // Capabilities provided to us by browser.
        // JS might be single threaded but these Web Api are multi threaded.
        // So JS actually exports its tasks to these api's.
        // Browser then delegate new threads for side activities.
        // JS run time is single threaded by browser cab spawn new threads an assign tasks to them.
        // This is what gives JS the illusion of being multi threaded.
// Event Queue:
        // Just a queue data structure in which browser put's the callbacks to be executed. And from which it puts the callback into the call stack if the stack is empty.
//Event Loop:
        // This is a constantly running process that checks if the call stack is empty. If it is empty it checks if it has something in event queue.
        // If something found it puts it on to call stack.

// You cannot setState within your render(), coz it is supposed to be pure function without any side effects.
//render() is the most used life cycle method.
// componentDidMount allows side effects and setState call.
// calling setState() in CDM--> render()
// How to determine if two object contain same value?.. How to compare two objects for value.?
// const obj1={a:1}
// const obj2={a:1}
// console.log(obj1===obj2)//false


// obj={
//         f1:{
//                 fn:'faraz',
//                 ln:'ashraf'
//         },
//         f2:{
//                 age:'25',
//                 add:'patna'
//         }
// }


// console.log(obj['f1'])

// const keys = Object.keys(obj)
// keys.map(key=>{
//         console.log(Object.values(obj[key]))
// })

// function people(name,age){
//         this.name=name
//         this.age=age
// }
// people.prototype={
//         getName(){
//                 return this.name
//         }
// }

// people1 = new people('jazib','28')
// people2 = new people('faraz','30')

// console.log(people2.getName())
//console.log(people.prototype)

// var time = 'PT22H00M
// '
// const trimmedTime = time.slice(2)
// const timeArray = trimmedTime.split('H')
// console.log(timeArray)
// const hours = timeArray[0]
// console.log(hours)
// const treimmedMinuteArray = timeArray[1].split('M')
// const minutes = treimmedMinuteArray[0]

// console.log(hours, minutes)

// function getDateForDisplay(apiTime){
// const trimmedTime = apiTime.slice(2)
// const timeArray = trimmedTime.split('H')
// console.log(timeArray)
// const hours = timeArray[0]
// console.log(hours)
// const trimmedMinuteArray = timeArray[1].split('M')
// const minutes = trimmedMinuteArray[0]


// console.log(hours, minutes)

// }

// a=[]
// a.__proto__.myFun= function(){
//         console.log("fun")
// }

// console.log("a"+2)
// let a=[[1,2],[2,3],[3,4]]
// let b =[...a[0], ...a[1], ...a[2]]
// console.log(b)

// var newArray=[]
// a.map((thisArray)=>{
//         thisArray.map((thisElement)=>{
//                 if(!newArray.includes(thisElement)){
//                         newArray.push(thisElement)
//                 }
//         })


// }
// )

// let str = "qwert"
// console.log(str)
// str[0]='a' //  strings are immutable
// console.log(str)
// str="sss" // But the reference can be resigned
// console.log(str[0])

// const obj = {
//         fun1: function(){
//                 console.log("This is fun 1")
//         },
//         fun2: ()=>{
//                 console.log("This is fun2")
//         },

// }




// obj.fun1()
// obj.fun2()

//----------------------------------- How React Works ------------------------------------
// JSX --> Bable --> React--> elements which is nothing bt JS objects --> 
//Virtual DOM --> Any state update --> JS React element objects changes-->
// Diff ALgorithm to check what needs to be changed in Virtual DOM
// Result of Diff applied to Real DOM 

// React Vs ReactDOM --> Both the functionalities were in same library but later split.
// ReactDOM is like a glue between react elements and Real DOM
// How to gain access to a particular node in react --> ReactDOM.findDOMNode()
// React is used for --> Creating React elements from JSX and applying Life cycles to it.

// StateLess components --> Recieves props and renders it. --> presentational or dumb components.

// why do we get error when we don't import React in functional components?
// Because internally bable transpiles JSX into React.CreateElement

// Props are immutable data and are only supposed to be consumed by child components
// State is a mutable data structure that acts as local store for a component

// Controlled Components --> Components whose value is derived from the react state is controlled one.
// The source of truth for these components remains the react state.
// onChange of values we change the concerened property in state. The changed Value then Appears in controlled component.
// Example textfields in React components.
// With controlled component all state mutation is done through handlers.

// Uncontrolled Components --> These have there on way of mainting values and are not derived from react state.
// They store values internally
// Example <input> <textarea> from html.
// Its current value is directly got by querying Dom using Ref

//Example
// Controlled:
//<input type="text" value={value} onChange={handleChange} />

// Uncontrolled:
//<input type="text" defaultValue="foo" ref={inputRef} />
// Use `inputRef.current.value` to read the current value of <input>

// CDM --> After component element has been rendered to the dom.

//-------------------------Lazy laoding / Code spliting / dynammic bundle creation/ dynamic imports------------------
// import('./myModule').then((myModule)=>{ })
// Webpack does the code spliting
// It can be achieved using React.Lazy and Suspense Component
// const MylateLoadedComponent = React.Lazy(()=>import('./../myLateLoadedComponent'))
//<Suspense fallback=<Loader/>>
// <MylateLoadedComponent/>
//</Suspense>
// Suspense can be entrapped within ErrorBoundaries components

// Render method creates Dom Nodes


//---------------------------------Polyfills / Creating custom JS functions -----------------------
// Array.prototype.myMap= function(cb){
//         var newArray=[]
//         this.forEach((thisElement)=>{
//                 newArray.push(cb(thisElement))
//         })
//         return newArray    
// }

// a=[1,2,3,4]

// let r =a.myMap((item)=>{
//         return item*2
// })

//concat -- newArray = array1.concat(array2)

// why does arrow function not work as object methods
// Array.prototype.myConcat = function (array2){
//         var newArray = []
//         console.log("this",this)
//         newArray=[...this, ...array2]
//         return newArray
// }
// a=[1,2,3,4,5]
// b=[4, 6,7,9]
// console.log(a.myConcat(b))


//Filter



//Pro Tip: React state should be treated as immutable. We should never mutate this.state directly, as calling setState() afterward may replace the mutation you made.


// React Performance Optimizations
// 1. Immutable DS
// 2. Functional Components minifies better.
// 3. Code splitting.
// 4. React.Fragment as a wrapper
// 5. Limiting Number of times an event handler is called through throttle and debounce.
// 6. Memoization for api calls



// Filter Polyfill
// Array.prototype.myFilter = function(filteringFunction){
//         var filteredArray=[]
//         this.forEach((thisElement)=>{
//                 if(filteringFunction(thisElement)){
//                         filteredArray.push(thisElement)
//                 }

//         })
//         return filteredArray
// }

// const words = ['spray', 'limit', 'elite', 'exuberant', 'destruction', 'present'];

// const result = words.myFilter((thisElement)=>thisElement.length>1);

// console.log(result);


// Reduce Polyfills

// a=[1,2,3,4,5]
// let r = a.reduce((acc, thisElement)=>{
//         acc= acc+thisElement
//         return acc
// }, 20)

// console.log(r)

//Syntax --> a.reduce(reducerCallback, intialValue)

// use Case -- > Array flatenning.

// const sortedAlphabets = ['e','a','w','c'].sort((alp1,alp2)=>{
//         if(alp1>alp2){
//                 return 1
//         }
//         else {
//                 return -1
//         }
// })

// console.log(sortedAlphabets)

// Objects prototype is nothing but the prototype property of it's parent.
// Final link in prototype chain is null.

// var str = "abcbefg"
// console.log(str.substring(1,2))
// console.log(str.includes("ce"))

// function isSubstring(word,subStr){
//         const result = word.indexOf(subStr)
//         return (result!==-1)
// }

// console.log(isSubstring("abacdeeef","ac"))


// palindrome
// racecar
// console.log('racec'.split('').reverse())

// function ispalindrome(word){
//         return (word === word.split('').reverse().join(''))  
// }

// console.log(ispalindrome('mada'))


//Anagram -- mmaauio and amimoia

// function isAnagram(word1, word2){
//         count1={}
//         count2={}

//         for(let letter of word1){
//                 if(count1[letter]==undefined){
//                         count1[letter]=1
//                 }
//                 else{
//                         count1[letter]=count1[letter+1]

//                 }
                
//         }

//         for(let letter of word2){
//                 if(count2[letter]==undefined){
//                         count2[letter]=1
//                 }
//                 else{
//                         count2[letter]=count2[letter+1]

//                 }   
//         }

//         for(let letters in count1){
//                 if(count1[letters]!==count2[letters]){
//                         return false
//                 }
//         }
//         return true

// }

// console.log(isAnagram('racecar','carrac'))


// function findVowels(word){
//         vowels = {
//                 "a":0,
//                 "e":0,
//                 "i":0,
//                 "o":0,
//                 "u":0
//                 }

//         for(let letter of word){
//                 if(['a','e','i','o','u'].includes(letter)){
//                         vowels[letter] = vowels[letter]+1
//                 }
//         }
//         return vowels
// }


// Linked List

// function Node(key){
//         this.Key=key
//         this.next=null
// }

// function LinkedList(){
//         this.head=null
//         this.NoOfNodes = 0

        
//         // Add New Node to Linked list
//         this.addNode = function(key){
//                 const newNode = new Node(key)
//                 if(this.head == null){
//                         this.head = newNode
//                         this.NoOfNodes=this.NoOfNodes+1

//                 }
//                 else{
//                         lastNode = this.getLastNode()
//                         lastNode.next = newNode
//                         this.NoOfNodes = this.NoOfNodes + 1
//                 }
//         }


//         // Get Last Node of the Linked List
//         this.getLastNode = function(){
//                 var currentNode = this.head
//                 while(currentNode.next!==null){
//                         currentNode = currentNode.next
//                 }

//                 return currentNode
//         }


//         // Insert at a given position in Linked list
//         this.insertNode = function(key, position){
//                 const newNode = new Node(key)
//                 nodeBeforePosition = this.getNodeAtPosition(position-1)
//                 newNode.next = nodeBeforePosition.next
//                 nodeBeforePosition.next = newNode
//         }


//         this.getNodeAtPosition = function(){
//                 var currentNode = this.head
//                 for(let i=1;i<=position;i++){
//                         currentNode = currentNode.next

//                 }
//                 return currentNode
//         }
// }

// reversing a number---

// function reverseNumber(number){
//         strNum = number.toString()
//         const reversedNumber = strNum.split('').reverse().join('')
//         return reversedNumber
// }
// console.log("reversedNumbver",reverseNumber(12345))





const arr = [10, 12, 15, 21];
for (var i = 0; i < arr.length; i++) {
  setTimeout((i)=> {
    console.log('Index: ' + i + ', element: ' + arr[i]);
  },0);
}





