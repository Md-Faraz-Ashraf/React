// function test(a,b,...rest){
//     console.log(a,b)
//     console.log(rest)
//     console.log(arguments)
// }

// var name

// function Person(name,age){
//     this.name=name,
//     this.age=age;
//     this.isAdult= function(){
//         // for methods this refers to current scope.
//         if(this.age>18){
//             console.log("Adult")
//         }
//         else{
//             console.log("Minor")
//         }
//     }
// }



// function Artist(){
//     this.paintings=''
// }

// function Player(){
//     this.sport=''
// }

// var john =  new Person('john','5')

// john.isAdult()


//var a=[1,2,3,4]

// Implemeting map function.
// function myMap(arr,cb){
//     let temp=[]
//     for(let i=0;i<arr.length;i++){
//         console.log(arr[i],cb(arr[i]))
//         temp.push(cb(arr[i]))
//     }
//     return temp
// }
// cb1=(item)=>item*2
// cb2=item=>item-1000;
// console.log(myMap(a,cb2))


// Functions returning functions pattern
// function multiply(a){
//     return function(b){ console.log(3*8)}
// }
// multiply(3)(8)
// same as below
// var mul = multiply(3)
// mul(8)



//IIFE
// How does this pattern creates data privacy?
// Used in Module patterns.
// Earlier when we did not have block scope we could use IIFE for data privacy.
// But now we have let and const for same.
// (
//     (name)=>console.log(name)
// )('jazib')

// !function(item){
//     console.log(item)
// }('item')
//


//Closures
