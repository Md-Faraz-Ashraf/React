var person = function(name, age){
    this.name=name,
    this.age=age
}

    // Person.prototype.isAdult = function(){
    //     if (this.age>18){
    //         return "Adult"
    //     }
    //     else{
    //         return "Minor"
    //     }
    // }

