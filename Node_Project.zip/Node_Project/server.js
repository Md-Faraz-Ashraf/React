const http = require('http')
const url= require('url') //For url resolution and parsing
const querystring= require('querystring')
const server= http.createServer((request,response)=>{
    const urlObject =url.parse(request.url) // It basically converts url into object of Url.
    console.log(urlObject.path)
    //console.log(url.parse(urlObject.path))
    console.log(querystring.parse(urlObject.query))
    // Simple steps:
            // 1. parse request.url to UrlObject.
            // 2. Now complete path (minus domain) is UrlObject.path 
            // 3. NOw querySting is urlObject.query
            // 4. Convert queryStirng to qsObject 
        
})


server.listen(3000,()=>{
    console.log("Server started!")
})