//Event module
const events = require('events') 
const fs = require('fs')
// one of the things prresent in event object is emitEmitter Constuctor

const myEmitter = new events.EventEmitter()

const listener1=()=>{
    console.log("Event 1 emmitted")
}

myEmitter.on('event1',listener1) //Event emmitter object can be used to register listener
myEmitter.emit('event1') // Is also used to emit events.

const myWritableStream = fs.createWriteStream()




 